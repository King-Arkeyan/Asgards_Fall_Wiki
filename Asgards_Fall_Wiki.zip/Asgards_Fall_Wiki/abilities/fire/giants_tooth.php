<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Giant's Tooth</title>
    <link rel="stylesheet" href="/Asgards_Fall_Wiki/assets/css/style.css" />
  </head>

<?php require '/xampp/htdocs/Asgards_Fall_Wiki/components/sections/header.php'; ?>

    <main>
      <div class="background">
        <span class="left1 fire"></span>
        <span class="left2 fire"></span>
        <span class="right1 fire"></span>
        <span class="right2 fire"></span>
      </div>
        <div class="container">
            <div class="space"></div>
            <div class="box fire row">
                <div class="col-12 main-card fire">
                    <div class="main-card-title">Giant's Tooth</div>
                </div>
                <div class="col-12 card fire">
                    <img src="/Asgards_Fall_Wiki/assets/img/abilities/fire/giants_tooth.png" alt="" class="card-icon">
                    <div class="card-title fire">Pierce random targets with massive spears.</div>
                    <table class="card-desc fire">
                        <tr class="fire">
                            <thead class="fire">
                                <th class="fire">Base Damage</th>
                                <th class="fire">Base Cooldown</th>
                                <th class="fire">Base Amount</th>
                                <th class="fire">Ability Type</th>
                            </thead>
                            <tbody class="fire">
                                <td class="fire">40</td>
                                <td class="fire">3</td>
                                <td class="fire">3</td>
                                <td class="fire">Melee</td>
                            </tbody>
                        </tr>
                    </table>
                    <a href="/Asgards_Fall_Wiki/abilities/fire.php" class="card-button fire">Fire Abilities</a>
                </div>
            </div>
            <div class="space"></div>
        </div>
    </main>
  </body>
</html>
