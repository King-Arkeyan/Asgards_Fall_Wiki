<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Molten Trap</title>
    <link rel="stylesheet" href="/Asgards_Fall_Wiki/assets/css/style.css" />
  </head>

<?php require '/xampp/htdocs/Asgards_Fall_Wiki/components/sections/header.php'; ?>

    <main>
      <div class="background">
        <span class="left1 fire"></span>
        <span class="left2 fire"></span>
        <span class="right1 fire"></span>
        <span class="right2 fire"></span>
      </div>
        <div class="container">
            <div class="space"></div>
            <div class="box fire row">
                <div class="col-12 main-card fire">
                    <div class="main-card-title">Molten Trap</div>
                </div>
                <div class="col-12 card fire">
                    <img src="/Asgards_Fall_Wiki/assets/img/abilities/fire/molten_trap.png" alt="" class="card-icon">
                    <div class="card-title fire">Place a molten trap beneath you that triggers a rotating firebeam upon enemy contact.</div>
                    <table class="card-desc fire">
                        <tr class="fire">
                            <thead class="fire">
                                <th class="fire">Base Damage</th>
                                <th class="fire">Base Cooldown</th>
                                <th class="fire">Base Amount</th>
                                <th class="fire">Ability Type</th>
                            </thead>
                            <tbody class="fire">
                                <td class="fire">50</td>
                                <td class="fire">6</td>
                                <td class="fire">1</td>
                                <td class="fire">Trap</td>
                            </tbody>
                        </tr>
                    </table>
                    <a href="/Asgards_Fall_Wiki/abilities/fire.php" class="card-button fire">Fire Abilities</a>
                </div>
            </div>
            <div class="space"></div>
        </div>
    </main>
  </body>
</html>
