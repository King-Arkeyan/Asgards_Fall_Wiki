<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Thunderclaw</title>
    <link rel="stylesheet" href="/Asgards_Fall_Wiki/assets/css/style.css" />
  </head>

<?php require '/xampp/htdocs/Asgards_Fall_Wiki/components/sections/header.php'; ?>

    <main>
      <div class="background">
        <span class="left1 forged"></span>
        <span class="left2 forged"></span>
        <span class="right1 forged"></span>
        <span class="right2 forged"></span>
      </div>
        <div class="container">
            <div class="space"></div>
            <div class="box forged row">
                <div class="col-12 main-card forged">
                    <div class="main-card-title">Thunderclaw</div>
                </div>
                <div class="col-12 card forged">
                    <img src="/Asgards_Fall_Wiki/assets/img/abilities/forged/thunderclaw.png" alt="" class="card-icon">
                    <div class="card-title forged">Fenrir gets infused with electric energy and slashes brutally through random targets.</div>
                    <table class="card-desc forged">
                        <tr class="forged">
                            <thead class="forged">
                                <th class="forged">Base Damage</th>
                                <th class="forged">Base Cooldown</th>
                                <th class="forged">Base Amount</th>
                                <th class="forged">Damage Type</th>
                                <th class="forged">Ability Type</th>
                                <th class="forged">Ability 1</th>
                                <th class="forged">Ability 2</th>
                            </thead>
                            <tbody class="forged">
                                <td class="forged">200</td>
                                <td class="forged">8</td>
                                <td class="forged">5</td>
                                <td class="forged">Physical / Lightning</td>
                                <td class="forged">Ranged</td>
                                <td class="forged">Fenrir's Claws</td>
                                <td class="forged">Thor's Wrath</td>
                            </tbody>
                        </tr>
                    </table>
                    <a href="/Asgards_Fall_Wiki/abilities/forged.php" class="card-button forged">Forged Abilities</a>
                </div>
            </div>
            <div class="space"></div>
        </div>
    </main>
  </body>
</html>
