<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Bone-Chilling Cold</title>
    <link rel="stylesheet" href="/Asgards_Fall_Wiki/assets/css/style.css" />
  </head>

<?php require '/xampp/htdocs/Asgards_Fall_Wiki/components/sections/header.php'; ?>

    <main>
      <div class="background">
        <span class="left1 ice"></span>
        <span class="left2 ice"></span>
        <span class="right1 ice"></span>
        <span class="right2 ice"></span>
      </div>
        <div class="container">
            <div class="space"></div>
            <div class="box ice row">
                <div class="col-12 main-card ice">
                    <div class="main-card-title">Bone-Chilling Cold</div>
                </div>
                <div class="col-12 card ice">
                    <img src="/Asgards_Fall_Wiki/assets/img/abilities/ice/bone-chilling_cold.png" alt="" class="card-icon">
                    <div class="card-title ice">Create a persistent aura around you that slows enemies and applies the Chill effect.</div>
                    <table class="card-desc ice">
                        <tr class="ice">
                            <thead class="ice">
                                <th class="ice">Base Damage</th>
                                <th class="ice">Base Cooldown</th>
                                <th class="ice">Base Amount</th>
                                <th class="ice">Ability Type</th>
                            </thead>
                            <tbody class="ice">
                                <td class="ice">None</td>
                                <td class="ice">None</td>
                                <td class="ice">None</td>
                                <td class="ice">Aura</td>
                            </tbody>
                        </tr>
                    </table>
                    <a href="/Asgards_Fall_Wiki/abilities/ice.php" class="card-button ice">Ice Abilities</a>
                </div>
            </div>
            <div class="space"></div>
        </div>
    </main>
  </body>
</html>
