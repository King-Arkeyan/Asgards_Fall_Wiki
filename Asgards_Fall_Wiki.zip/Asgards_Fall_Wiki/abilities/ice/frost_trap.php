<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Frost Trap</title>
    <link rel="stylesheet" href="/Asgards_Fall_Wiki/assets/css/style.css" />
  </head>

<?php require '/xampp/htdocs/Asgards_Fall_Wiki/components/sections/header.php'; ?>

    <main>
      <div class="background">
        <span class="left1 ice"></span>
        <span class="left2 ice"></span>
        <span class="right1 ice"></span>
        <span class="right2 ice"></span>
      </div>
        <div class="container">
            <div class="space"></div>
            <div class="box ice row">
                <div class="col-12 main-card ice">
                    <div class="main-card-title">Frost Trap</div>
                </div>
                <div class="col-12 card ice">
                    <img src="/Asgards_Fall_Wiki/assets/img/abilities/ice/frost_trap.png" alt="" class="card-icon">
                    <div class="card-title ice">Places a frost trap beneath you that triggers piercing projectiles upon enemy contact.</div>
                    <table class="card-desc ice">
                        <tr class="ice">
                            <thead class="ice">
                                <th class="ice">Base Damage</th>
                                <th class="ice">Base Cooldown</th>
                                <th class="ice">Base Amount</th>
                                <th class="ice">Ability Type</th>
                            </thead>
                            <tbody class="ice">
                                <td class="ice">35</td>
                                <td class="ice">8</td>
                                <td class="ice">1</td>
                                <td class="ice">Trap</td>
                            </tbody>
                        </tr>
                    </table>
                    <a href="/Asgards_Fall_Wiki/abilities/ice.php" class="card-button ice">Ice Abilities</a>
                </div>
            </div>
            <div class="space"></div>
        </div>
    </main>
  </body>
</html>
