<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Thor's Wrath</title>
    <link rel="stylesheet" href="/Asgards_Fall_Wiki/assets/css/style.css" />
  </head>

<?php require '/xampp/htdocs/Asgards_Fall_Wiki/components/sections/header.php'; ?>

    <main>
      <div class="background">
        <span class="left1 lightning"></span>
        <span class="left2 lightning"></span>
        <span class="right1 lightning"></span>
        <span class="right2 lightning"></span>
      </div>
        <div class="container">
            <div class="space"></div>
            <div class="box lightning row">
                <div class="col-12 main-card lightning">
                    <div class="main-card-title">Thor's Wrath</div>
                </div>
                <div class="col-12 card lightning">
                    <img src="/Asgards_Fall_Wiki/assets/img/abilities/lightning/thors_wrath.png" alt="" class="card-icon">
                    <div class="card-title lightning">Call lightning from the sky hitting random targets and the surroundings.</div>
                    <table class="card-desc lightning">
                        <tr class="lightning">
                            <thead class="lightning">
                                <th class="lightning">Base Damage</th>
                                <th class="lightning">Base Cooldown</th>
                                <th class="lightning">Base Amount</th>
                                <th class="lightning">Ability Type</th>
                            </thead>
                            <tbody class="lightning">
                                <td class="lightning">50</td>
                                <td class="lightning">7</td>
                                <td class="lightning">3</td>
                                <td class="lightning">Ranged</td>
                            </tbody>
                        </tr>
                    </table>
                    <a href="/Asgards_Fall_Wiki/abilities/lightning.php" class="card-button lightning">Lightning Abilities</a>
                </div>
            </div>
            <div class="space"></div>
        </div>
    </main>
  </body>
</html>
