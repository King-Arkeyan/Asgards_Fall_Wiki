Home : true (main\_card)



=> Characters : true (characters\_card)



==> Warrior : true (informations\_card)

==> Huntress : true (informations\_card)

==> Seer : true (informations\_card)



=> Abilities : True (abilities\_card)



==> Physical : true (main\_card)



===> Ballista : true (informations\_card)

===> Dagger Throw : true (informations\_card)

===> Fenrir's Claws : true (informations\_card)

===> Ferocious Stomp : true (informations\_card)

===> Hammer of Righteous : true (informations\_card)

===> Hugin and Munin : true (informations\_card)

===> Ride of the Valkyries : true (informations\_card)

===> Shattering Ground : true (informations\_card)

===> Spear of the Elder : true (informations\_card)

===> Whirl Slash : true (informations\_card)



==> Fire : false (main\_card)



===> Ember Axe : false (informations\_card)

===> Fiery Rune : false (informations\_card)

===> Firewolf's Fury : false (informations\_card)

===> Flamebound Leech : false (informations\_card)

===> Flesh-Searing Heat : false (informations\_card)

===> Giant's Tooth : false (informations\_card)

===> Jotunfire Outburst : false (informations\_card)

===> Magma Sphere : false (informations\_card)

===> Molten Trap : false (informations\_card)

===> Surtur's Inferno : false (informations\_card)



==> Ice : false (main\_card)



===> Arctic Assault : false (informations\_card)

===> Bone-chilling Cold : false (informations\_card)

===> Flurry of Knives : false (informations\_card)

===> Frost Orbit : false (informations\_card)

===> Frost Trap : false (informations\_card)

===> Glacial Sunder : false (informations\_card)

===> Leviathan Axe Throw : false (informations\_card)

===> Skadi's Ice Arrow : false (informations\_card)

===> Ymir's Avalanche : false (informations\_card)



==> Lightning : false (main\_card)



===> Gungnir : false (informations\_card)

===> Loki's Electric Mirage : false (informations\_card)

===> Mjölnir : false (informations\_card)

===> Serpents Coil : false (informations\_card)

===> Thor's Wrath : false (informations\_card)

===> Thunderous Tether : false (informations\_card)

===> Tyr's Judgement : false (informations\_card)

===> Yggdrasil's Pulse : false (informations\_card)



==> Forged : false (main\_card)



===> Shattering Leviathan Axe : false (informations\_card)

===> Electrified Axes : false (informations\_card)

===> Burning Chaos Blades : false (informations\_card)

===> Odin's Ice Arrows : false (informations\_card)

===> Stormpiercer : false (informations\_card)

===> Frostfang Ring : false (informations\_card)

===> Thunderclaw : false (informations\_card)

===> Helstorm : false (informations\_card)

